-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Apr 2022 pada 17.29
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tubesabp`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun`
--

CREATE TABLE `akun` (
  `username` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `akun`
--

INSERT INTO `akun` (`username`, `email`, `password`, `created_at`, `updated_at`) VALUES
('alifiya', 'alifiya72@gmail.com', '123098', '2022-04-18 06:47:48', '2022-04-18 06:47:48'),
('artisabunga', 'artisa3110bunga@gmial.com', '98765', '2022-04-12 17:13:10', '2022-04-12 17:19:08'),
('bubu', 'artisabunga@student.telkomuniversity.ac.id', '99999', '2022-04-18 08:06:51', '2022-04-18 08:06:51'),
('ikiyu', 'iki123@gmail.com', '00000', '2022-04-18 06:58:18', '2022-04-18 06:58:18'),
('ridha', 'ridhazalfas1000@outlook.com', '11111', '2022-04-18 06:50:11', '2022-04-18 06:50:11'),
('salsa', 'salsabila@yahoo.com', '102938', '2022-04-18 06:49:27', '2022-04-18 06:49:27'),
('syifa', 'syifameisia3005@gmail.com', '12345', '2022-04-12 18:31:36', '2022-04-12 18:31:36');

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu`
--

CREATE TABLE `menu` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `harga` int(11) NOT NULL,
  `gambar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `menu`
--

INSERT INTO `menu` (`id`, `nama`, `deskripsi`, `harga`, `gambar`, `created_at`, `updated_at`) VALUES
(3, 'Paket sarapan', 'Sereal dengan susu dan kopi panas', 30000, 'WhatsApp Image 2022-04-18 at 20.16.11 (1).jpeg', '2022-04-18 06:34:47', '2022-04-18 06:34:47'),
(4, 'onde-onde', 'onde-onde dengan isian kacang hijau', 10000, 'WhatsApp Image 2022-04-18 at 20.16.11 (2).jpeg', '2022-04-18 06:35:14', '2022-04-18 06:35:14'),
(5, 'French fries', 'Kentang Goreng', 17000, 'WhatsApp Image 2022-04-18 at 20.16.12.jpeg', '2022-04-18 06:36:20', '2022-04-18 06:36:20'),
(6, 'Taiyaki', 'Kue isian kacang merah', 15000, 'WhatsApp Image 2022-04-18 at 20.16.12 (1).jpeg', '2022-04-18 06:37:10', '2022-04-18 06:37:10'),
(7, 'Waffle Ice Cream', 'Ice Cream dengan waffle renyah', 20000, 'WhatsApp Image 2022-04-18 at 20.17.30.jpeg', '2022-04-18 06:39:11', '2022-04-18 06:39:11'),
(8, 'Fried Rice', 'Nasi Goreng Special dengan Telor', 15000, 'WhatsApp Image 2022-04-18 at 20.42.14.jpeg', '2022-04-18 06:42:50', '2022-04-18 06:42:50'),
(9, 'Garlic Bread', 'Roti dengan rasa bawang putih dan keju', 15000, 'WhatsApp Image 2022-04-18 at 20.16.11.jpeg', '2022-04-18 06:44:44', '2022-04-18 06:44:44'),
(10, 'ice lemon tea', 'es teh dan lemon segar', 10000, '5ea69f8562f36.jpg', '2022-04-18 07:13:22', '2022-04-18 07:13:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2022_04_07_024924_create_menu_table', 1),
(7, '2022_04_11_133151_create_akun_table', 1),
(8, '2022_04_11_151010_create_registrasi_table', 1),
(9, '2022_04_12_090354_transaksi_masuk', 1),
(10, '2022_04_12_090447_transaksi_berlangsung', 1),
(11, '2022_04_12_090519_transaksi_riwayat', 1),
(12, '2022_04_12_094343_add_google_id_column', 1),
(13, '2022_04_12_094612_create_sessions_table', 1),
(14, '2022_04_12_101237_add_facebook_id_column', 1),
(15, '2022_04_12_145701_create_registrasi1_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `registrasi`
--

CREATE TABLE `registrasi` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lokasi_meja` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_meja` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah_meja` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `registrasi`
--

INSERT INTO `registrasi` (`id`, `lokasi_meja`, `jenis_meja`, `jumlah_meja`, `created_at`, `updated_at`) VALUES
(7, 'Indoor', 'Meja duduk', '2', '2022-04-18 06:17:34', '2022-04-18 06:17:34'),
(8, 'Indoor', 'Meja duduk', '2', '2022-04-18 06:17:38', '2022-04-18 06:17:38'),
(11, 'Indoor', 'Meja duduk', '4', '2022-04-18 06:17:57', '2022-04-18 06:17:57'),
(12, 'Indoor', 'Meja duduk', '4', '2022-04-18 06:18:02', '2022-04-18 06:18:02'),
(13, 'Indoor', 'Meja duduk', '4', '2022-04-18 06:18:07', '2022-04-18 06:18:07'),
(14, 'Indoor', 'Lesehan', '9', '2022-04-18 06:28:22', '2022-04-18 06:28:22'),
(15, 'Indoor', 'Meja duduk', '6', '2022-04-18 06:30:08', '2022-04-18 06:30:08'),
(16, 'Outdoor', 'Meja duduk', '4', '2022-04-18 06:32:09', '2022-04-18 06:32:09'),
(17, 'Indoor', 'Meja duduk', '9', '2022-04-18 07:13:42', '2022-04-18 07:13:42');

-- --------------------------------------------------------

--
-- Struktur dari tabel `registrasi1`
--

CREATE TABLE `registrasi1` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kota` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kecamatan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kodepos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `registrasi1`
--

INSERT INTO `registrasi1` (`id`, `image`, `nama`, `alamat`, `kota`, `kecamatan`, `kodepos`, `kategori`, `created_at`, `updated_at`) VALUES
(1, 'logo telkom.jpg', 'alibaba', 'asdfg', 'Bandung', 'Arcamanik', '12345', 'Makanan Tradisional', '2022-04-18 07:11:22', '2022-04-18 07:11:22'),
(2, '5ea69f8562f36.jpg', 'baba', 'asdfg', 'Bandung', 'Arcamanik', '12345', 'Makanan Tradisional', '2022-04-18 08:12:52', '2022-04-18 08:12:52');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('7TmRbHkwSUZHOHrCL33TVRpAMzv3yXIEhLg8dcGQ', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibThCWVk2R1JnRmJZSHdOdHBqMXNUbUFhVlZSa0RSQ2NBMzd5U21COCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9kYXNib2FyMyI7fX0=', 1650295750);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_berlangsung`
--

CREATE TABLE `transaksi_berlangsung` (
  `idReservasi` int(10) UNSIGNED NOT NULL,
  `idResto` int(11) NOT NULL,
  `idCust` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_reservasi` date NOT NULL,
  `time_reservasi` time NOT NULL,
  `no_table` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `transaksi_berlangsung`
--

INSERT INTO `transaksi_berlangsung` (`idReservasi`, `idResto`, `idCust`, `created_at`, `updated_at`, `date_reservasi`, `time_reservasi`, `no_table`) VALUES
(2, 1234112, 12123111, '2022-04-18 05:45:06', '2022-04-18 05:45:06', '2022-04-14', '12:00:00', 2),
(3, 1234112, 12112311, '2022-04-18 05:43:16', '2022-04-18 05:43:16', '2022-04-14', '08:15:00', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_masuk`
--

CREATE TABLE `transaksi_masuk` (
  `idReservasi` int(10) UNSIGNED NOT NULL,
  `idResto` int(11) NOT NULL,
  `idCust` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_reservasi` date NOT NULL,
  `time_reservasi` time NOT NULL,
  `no_table` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `transaksi_masuk`
--

INSERT INTO `transaksi_masuk` (`idReservasi`, `idResto`, `idCust`, `created_at`, `updated_at`, `date_reservasi`, `time_reservasi`, `no_table`) VALUES
(7, 1234112, 12112111, '2022-04-13 00:12:47', '2022-04-13 00:12:47', '2022-04-14', '09:15:00', 3),
(8, 1234112, 12122312, '2022-04-18 13:51:13', '2022-04-18 13:51:13', '2022-04-15', '08:20:00', 2),
(9, 1234112, 12124533, '2022-04-18 13:51:13', '2022-04-18 13:51:13', '2022-04-14', '20:00:00', 11),
(10, 1234112, 12112412, '2022-04-18 13:51:13', '2022-04-18 13:51:13', '2022-04-15', '10:15:00', 6),
(11, 1234112, 12121234, '2022-04-18 13:51:13', '2022-04-18 13:51:13', '2022-04-13', '16:30:00', 5),
(12, 1234112, 12154321, '2022-04-18 13:51:13', '2022-04-18 13:51:13', '2022-04-14', '10:30:00', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_riwayat`
--

CREATE TABLE `transaksi_riwayat` (
  `idReservasi` int(10) UNSIGNED NOT NULL,
  `idResto` int(11) NOT NULL,
  `idCust` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_reservasi` date NOT NULL,
  `time_reservasi` time NOT NULL,
  `no_table` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `transaksi_riwayat`
--

INSERT INTO `transaksi_riwayat` (`idReservasi`, `idResto`, `idCust`, `created_at`, `updated_at`, `date_reservasi`, `time_reservasi`, `no_table`) VALUES
(1, 1234112, 1221451, '2022-04-18 06:51:42', '2022-04-18 06:51:42', '2022-04-15', '13:15:00', 5),
(5, 1234112, 12112412, '2022-04-18 06:09:13', '2022-04-18 06:09:13', '2022-04-15', '10:15:00', 6);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indeks untuk tabel `registrasi`
--
ALTER TABLE `registrasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `registrasi1`
--
ALTER TABLE `registrasi1`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indeks untuk tabel `transaksi_berlangsung`
--
ALTER TABLE `transaksi_berlangsung`
  ADD PRIMARY KEY (`idReservasi`);

--
-- Indeks untuk tabel `transaksi_masuk`
--
ALTER TABLE `transaksi_masuk`
  ADD PRIMARY KEY (`idReservasi`);

--
-- Indeks untuk tabel `transaksi_riwayat`
--
ALTER TABLE `transaksi_riwayat`
  ADD PRIMARY KEY (`idReservasi`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `menu`
--
ALTER TABLE `menu`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `registrasi`
--
ALTER TABLE `registrasi`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `registrasi1`
--
ALTER TABLE `registrasi1`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `transaksi_berlangsung`
--
ALTER TABLE `transaksi_berlangsung`
  MODIFY `idReservasi` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `transaksi_masuk`
--
ALTER TABLE `transaksi_masuk`
  MODIFY `idReservasi` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `transaksi_riwayat`
--
ALTER TABLE `transaksi_riwayat`
  MODIFY `idReservasi` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
